Aliaksandr Ivanou

relations.rkt -- there are 2 versions of restrict
one based on sets(intersection , union of sets)
another (restrict-single-entity ; based on boolean logic)

dice.rkt dice.erl - breath first search, 
with storing vertices after finishing dice list.


